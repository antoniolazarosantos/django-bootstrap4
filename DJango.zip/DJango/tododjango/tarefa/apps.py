from django.apps import AppConfig


class TarefaConfig(AppConfig):
    name = 'tarefa'
