from django.apps import AppConfig


class RelatorioetdConfig(AppConfig):
    name = 'relatorioetd'
