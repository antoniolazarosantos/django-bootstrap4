from django.conf import settings
import os
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect
from .models import RelatorioEtdBd
from .forms import ConfigurarFormulario
from .etd import ETD


def index(request):
    registros = RelatorioEtdBd.objects.all().order_by('-id')[:7]
    form = ConfigurarFormulario()
    if request.method == 'POST' and request.FILES['arquivo']:
        form = ConfigurarFormulario(request.POST)
        arquivo = request.FILES['arquivo']
        fs = FileSystemStorage()
        filename = fs.save(arquivo.name, arquivo)
        url_local_arquivo = fs.url(filename)
        base_dir = settings.MEDIA_ROOT
        meu_arquivo = os.path.join(base_dir, str(arquivo.name))
        e = ETD()
        registro_etd = e.Registro(meu_arquivo)
        fs.delete(arquivo.name)
        f = RelatorioEtdBd.objects.filter(data=registro_etd["Data"], hora=registro_etd["Hora"])
        if not f.exists():
            print("Inserindo...")
            novo_registro = RelatorioEtdBd()
            novo_registro.data = registro_etd["Data"]
            novo_registro.hora = registro_etd["Hora"]
            novo_registro.planning = registro_etd["Planning"]
            novo_registro.picking = registro_etd["Picking"]
            novo_registro.packing = registro_etd["Packing"]
            novo_registro.shipping = registro_etd["Shipping"]
            novo_registro.save(force_insert=True)
            registros = RelatorioEtdBd.objects.all().order_by('-id')[:7]

        contexto = {
            'form': form,
            'registros': registros,
            'url_local_arquivo': url_local_arquivo,
            'classe_mensagem': 'sucesso',
            'mensagem': "Arquivo {0} carregado com sucesso!".format(arquivo.name)
        }
        return render(request, 'carregararquivo.html', contexto)
    else:
        contexto = {
            'form': form,
            'registros': registros,
        }
    return render(request, 'carregararquivo.html', contexto)
