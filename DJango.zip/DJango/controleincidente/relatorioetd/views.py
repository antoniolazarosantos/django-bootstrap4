from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect
from .models import RelatorioEtdBd
from .forms import ConfigurarFormulario


def index(request):
    registros = RelatorioEtdBd.objects.all().order_by('data')[:7]
    form = ConfigurarFormulario()
    if request.method == 'POST' and request.FILES['arquivo']:
        form = ConfigurarFormulario(request.POST)
        arquivo = request.FILES['arquivo']
        fs = FileSystemStorage()
        filename = fs.save(arquivo.name, arquivo)
        url_local_arquivo = fs.url(filename)
        contexto = {
            'form': form,
            'registros': registros,
            'url_local_arquivo': url_local_arquivo,
            'classe_mensagem': 'sucesso',
            'mensagem': "Arquivo {0} carregado com sucesso!".format(arquivo.name)
        }
        return render(request, 'carregararquivo.html', contexto)
    else:
        contexto = {
            'form': form,
            'registros': registros,
        }
    return render(request, 'carregararquivo.html', contexto)
