from django.conf import settings
import os
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect
from .models import RelatorioEtdBd
from .forms import ConfigurarFormulario
from .etd import ETD
from .GoogleSheets import GoogleSheet


def atualizarGoogleSheets(pregistro):
    gs = GoogleSheet()
    wk = gs.AbrirPlanilha('1G6tMCiGFSbrlpWd2iN6Ic7NHxuZ-At5aRFc5r2JSdRk')
    t_valores = (
    pregistro.data, pregistro.hora, pregistro.planning, pregistro.picking, pregistro.packing, pregistro.shipping)
    wk.append_row(list(t_valores), value_input_option='USER_ENTERED')
    # Atualiza uma única linha da planilha de etd
    wk = gs.AbrirPlanilha('1WIg_LA4tkuKbyGWl7POLjucHFR26R8njt1zPLHHF9O4')
    wk.clear()
    t_cabecalho = ("Data", "Hora", "Planning", "Picking", "Packing", "Shipping")
    wk.append_row(list(t_cabecalho), value_input_option='USER_ENTERED')
    wk.append_row(list(t_valores), value_input_option='USER_ENTERED')


def index(request):
    registros = RelatorioEtdBd.objects.all().order_by('-id')[:7]
    form = ConfigurarFormulario()
    if request.method == 'POST' and request.FILES['arquivo']:
        form = ConfigurarFormulario(request.POST)
        arquivo = request.FILES['arquivo']
        if len(arquivo) > 0:
            fs = FileSystemStorage()
            filename = fs.save(arquivo.name, arquivo)
            url_local_arquivo = fs.url(filename)
            base_dir = settings.MEDIA_ROOT
            meu_arquivo = os.path.join(base_dir, str(arquivo.name))
            e = ETD()
            registro_etd = e.Registro(meu_arquivo)
            fs.delete(arquivo.name)
            f = RelatorioEtdBd.objects.filter(data=registro_etd["Data"], hora=registro_etd["Hora"])
            if not f.exists():
                novo_registro = RelatorioEtdBd()
                novo_registro.data = registro_etd["Data"]
                novo_registro.hora = registro_etd["Hora"]
                novo_registro.planning = registro_etd["Planning"]
                novo_registro.picking = registro_etd["Picking"]
                novo_registro.packing = registro_etd["Packing"]
                novo_registro.shipping = registro_etd["Shipping"]
                novo_registro.save(force_insert=True)
                atualizarGoogleSheets(novo_registro)
                registros = RelatorioEtdBd.objects.all().order_by('-id')[:7]

        contexto = {
            'form': form,
            'registros': registros,
            'url_local_arquivo': url_local_arquivo,
            'classe_mensagem': 'sucesso',
            'mensagem': "Arquivo {0} carregado com sucesso!".format(arquivo.name)
        }
        return render(request, 'carregararquivo.html', contexto)
    else:
        contexto = {
            'form': form,
            'registros': registros,
        }
    return render(request, 'carregararquivo.html', contexto)
