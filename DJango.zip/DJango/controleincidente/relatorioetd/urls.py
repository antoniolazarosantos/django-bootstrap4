from django.urls import path
from . import views
from django.views.generic.base import RedirectView

urlpatterns = [
    path('relatorioetd/', views.index),
    path('', RedirectView.as_view(url='relatorioetd/'))
]