from django.contrib import admin
from .models import RelatorioEtdBd


# Register your models here.
@admin.register(RelatorioEtdBd)
class RelatorioEtdAdmin(admin.ModelAdmin):
    list_display = ['id', 'data', 'hora', 'planning', 'picking', 'packing',
                    'shipping',]
