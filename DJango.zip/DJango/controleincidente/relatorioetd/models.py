from django.db import models


# Create your models here.

class RelatorioEtdBd(models.Model):
    data = models.CharField(max_length=10, blank=False, null=False)
    hora = models.CharField(max_length=5,null=False, blank=False)
    planning = models.BigIntegerField(default=0, null=False, blank=False)
    picking = models.BigIntegerField(default=0, null=False, blank=False)
    packing = models.BigIntegerField(default=0, null=False, blank=False)
    shipping = models.BigIntegerField(default=0, null=False, blank=False)

    def __str__(self):
        return str(self.id)
