import sqlite3
import csv as cv
import sys
import os


class ETD:
    def Registro(self, parquivo):
        with open(parquivo, 'r') as read_obj:
            dict_reader = cv.DictReader(read_obj)
            lista = list(dict_reader)
            linha = lista[0]
            hora = linha['hora']
            hora = hora[7:]

            data = linha['data']
            data = data[7:]

            planning = linha['Planning']
            planning = planning[8:]
            planning = planning[1:len(planning) - 1]

            picking = linha['Picking']
            picking = picking[7:]
            picking = picking[1:len(picking) - 1]

            packing = linha['Packing']
            packing = packing[7:]
            packing = packing[1:len(packing) - 1]

            shipping = linha['Shipping']
            shipping = shipping[8:]
            shipping = shipping[1:len(shipping) - 1]

            dic = {"Data": data,
                   "Hora": hora,
                   "Planning": planning,
                   "Picking": picking,
                   "Packing": packing,
                   "Shipping": shipping}
            return dic