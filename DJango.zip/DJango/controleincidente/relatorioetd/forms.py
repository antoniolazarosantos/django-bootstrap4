from django import forms
from django.forms import NumberInput

from .models import RelatorioEtdBd


class ConfigurarFormulario(forms.ModelForm):
    data = forms.DateField(widget=NumberInput(attrs={'type': 'date'}), label="Data")
    hora = forms.TimeField(widget=NumberInput(attrs={'type': 'time'}), label="Hora")
    planning = forms.IntegerField(widget=NumberInput(attrs={'type': 'number'}), label="Planning")
    picking = forms.IntegerField(widget=NumberInput(attrs={'type': 'number'}), label="Picking")
    packing = forms.IntegerField(widget=NumberInput(attrs={'type': 'number'}), label="Packing")
    shipping = forms.IntegerField(widget=NumberInput(attrs={'type': 'number'}), label="Shipping")

    class Meta:
        model = RelatorioEtdBd
        fields = '__all__'
