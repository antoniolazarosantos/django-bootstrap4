from django.shortcuts import render, redirect
from .models import IncidenteBd
from .forms import ConteudoForm


# Create your views here.

def index(request):
    conteudo = IncidenteBd.objects.all()
    form = ConteudoForm()
    if request.method == 'POST':
        form = ConteudoForm(request.POST)
        if form.is_valid():
            form = form.save()
            return redirect('/')

    context = {
        'conteudos': conteudo,
        'form': form
    }
    return render(request, 'lista.html', context)


def delete_incidente(request, id):
    deleteIncidente = IncidenteBd.objects.get(id=id)
    deleteIncidente.delete()
    return redirect('/')


def editar_incidente(request, id):
    editarIncidente = IncidenteBd.objects.get(id=id)

    form = ConteudoForm(instance=editarIncidente)
    if request.method == 'POST':
        form = ConteudoForm(request.POST, instance=editarIncidente)
        if form.is_valid():
            form.save()
            return redirect('/')
    context = {
        'form': form,

    }
    return render(request, 'editar.html', context)