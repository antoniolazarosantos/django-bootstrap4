from django import forms
from django.forms import NumberInput

from .models import IncidenteBd


class ConteudoForm(forms.ModelForm):
    data = forms.DateField(widget=NumberInput(attrs={'type': 'date'}), label="Data")
    inicio_data = forms.DateField(widget=NumberInput(attrs={'type': 'date'}), label="Data de Início")
    termino_data = forms.DateField(widget=NumberInput(attrs={'type': 'date'}), label="Data de Término")
    inicio_hora = forms.TimeField(widget=NumberInput(attrs={'type': 'time'}), label="Hora de Início")
    termino_hora = forms.TimeField(widget=NumberInput(attrs={'type': 'time'}), label="Hora Término")
    descricao = forms.CharField(widget=forms.Textarea(attrs={'rows': 3}), label="Descrição")

    class Meta:
        model = IncidenteBd
        fields = '__all__'
