from django.contrib import admin
from .models import IncidenteBd


# Register your models here.
@admin.register(IncidenteBd)
class IncidenteAdmin(admin.ModelAdmin):
    list_display = ['id', 'data', 'turno', 'inicio_data', 'inicio_hora', 'termino_data',
                    'termino_hora', 'quantidade','descricao', ]
