from django.db import models


# Create your models here.

class IncidenteBd(models.Model):
    data = models.DateField(auto_now_add=False, blank=False, null=False)
    turno_valores = (
        ('M', 'Matutino'),
        ('V', 'Vespertino'),
        ('N', 'Noturno'),
    )
    turno = models.CharField(
        max_length=1,
        choices=turno_valores,
        default='N',
    )
    inicio_data = models.DateField(null=False, blank=False)
    inicio_hora = models.TimeField(null=False, blank=False)
    termino_data = models.DateField(null=False, blank=False)
    termino_hora = models.TimeField(null=False, blank=False)
    quantidade = models.IntegerField(default=0, null=False, blank=False)
    descricao = models.CharField(max_length=1000, blank=False, null=False)

    def __str__(self):
        return str(self.id)