from django.apps import AppConfig


class IncidenteConfig(AppConfig):
    name = 'incidente'
