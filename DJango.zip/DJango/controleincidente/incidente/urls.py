from django.urls import path
from . import views
from django.views.generic.base import RedirectView

urlpatterns = [
    path('incidente/', views.index),
    path('incidente/delete/<slug:id>', views.delete_incidente),
    path('incidente/editar/<int:id>', views.editar_incidente, name='editar incidente'),
    path('', RedirectView.as_view(url='incidente/'))
]
